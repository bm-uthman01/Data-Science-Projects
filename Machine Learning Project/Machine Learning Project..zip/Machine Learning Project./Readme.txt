
Submission of Uthman Maigari's machine learning coursework.


The zip folder contains two Matlab files that should run independently. We have (KNearestNeighbor_BayesianOpt.m). for K-NN. Random forest is represented by the files RandomForest_BayesianOpt.m My performance results are in a separate folder, along with the dataframe (Breastcancer.csv).


Matlab software version used is R2021 (9.11.0.1769968).

Operating System used is a Mac.