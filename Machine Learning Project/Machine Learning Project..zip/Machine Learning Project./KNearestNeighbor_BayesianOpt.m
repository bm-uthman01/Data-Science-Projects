tic
clear;
clc;

% importing the data

data = readtable('Breastcancer.csv');


% An analysis of the data indicates that three columns 
% (area_mean, area_se, and area_worst) contain substantial outliers.
summary(data);

% Independent and dependent variables separated
% The diagnosis feature will be my dependent variable (Y) because it is reliant on the other features. 
% As a result, the rest are independent features (X) because they are not dependent on anything.

depen_Y = table2array(data ...
    (:,2));
indepen_X = table2array(data ...
    (:,3:32));

% Variables are saved

depen_variables = data.Properties.VariableNames;
indepen_variables = data(:,3:end);

% defining classes

% The number of 'M'alignant tumors is 212 (1) and the number of 'B'enign tumors is 357 (0)
M_B_count = tabulate(depen_Y);
 


C_V = cvpartition(depen_Y, ...
    'holdout',0.3);

trainX = indepen_X(training ...
    (C_V,1),:);
trainy = depen_Y(training ...
    (C_V,1));
testX = indepen_X(test ...
    (C_V,1),:);
testy = depen_Y(test ...
    (C_V,1),:);


% In response to 3 significant outliers from the summary, 
% I normalized the data with mu=0 and standard deviation = 1.
[trainX, mu, stddev] = normalize(trainX);

for i=1:size(testX, 2)
    testX(:,i) = (testX(:,i) ...
        -mu(1,i))/stddev(1,i);
end


% As a result of the highly correlated dataset, the first tuning of hyperparameters was done by Bayesian optimi. 
% Based on this method, we are able to produce the following figures:
% The first one displays the two HP and the corresponding value of each repetition.
% The second graph shows the objective function's estimated and observed values.

rng(1)
Dis = optimizableVariable('Dis', {'minkowski','correlation','hamming',...
   'jaccard','mahalanobis','cityblock','euclidean','cosine','spearman'...
    'seuclidean','chebychev'},'Type','categorical');
k = optimizableVariable('k',[1,50],'Type','integer');



% Partitions and indexes for the second CVpartitioned dataset.
idxfold = size(trainX,1);
CV = cvpartition(idxfold, 'kfold', 10);

fun = @(x)kfoldLoss(fitcknn(trainX,trainy,'CVPartition',CV,'NumNeighbors', x.k, ...
    'Distance',char(x.Dis), 'NSMethod','exhaustive'));

% When trying for 200 observations, set the objective evaluation limit higher than the acquisition function.. 
% ...and expected improvement
bayesopt_results = bayesopt(fun,[k,Dis], 'Verbose',1, 'MaxObjectiveEvaluations', 200);


k_bayesopt = bayesopt_results.XAtMinObjective.k;
Dis2 = bayesopt_results.XAtMinObjective.Dis;


min_error = bayesopt_results.MinObjective; 


% An optimised hyperparameter model has been fitted.
bayes_opt_mdl_knn = fitcknn(trainX , trainy, 'NumNeighbors', k_bayesopt,'Distance',char(Dis2));
% returns predicted class labels based on the trained classification model
[bayes_opt_yPrd_knn, knn_scr_bayesopt,conio] = predict(bayes_opt_mdl_knn,testX); 
% classification effective of training data based on model predictions
bayes_opt_knn_loss = loss(bayes_opt_mdl_knn,testX, testy);
% Misclassifications from the predictions above 
bayes_opt_knn_rloss = resubLoss(bayes_opt_mdl_knn); 
rng(1)

% confusion matrix %
figure()

[Confmat_bayesopt_knn, order] = confusionmat(testy, bayes_opt_yPrd_knn);
matrix_graph = confusionchart( testy, bayes_opt_yPrd_knn);


% The accuracy 
Accuracy = 100*(Confmat_bayesopt_knn(1,1)+Confmat_bayesopt_knn(2,2))./(Confmat_bayesopt_knn(1,1)+Confmat_bayesopt_knn(2,2)+Confmat_bayesopt_knn(1,2)+Confmat_bayesopt_knn(2,1));

% Precision.
Precision = Confmat_bayesopt_knn(1,1)./(Confmat_bayesopt_knn(1,1)+Confmat_bayesopt_knn(1,2));

% As a result of recall, we can figure out how many samples have a real chance of being tumor positive.
Recall = Confmat_bayesopt_knn(1,1)./(Confmat_bayesopt_knn(1,1)+Confmat_bayesopt_knn(2,1));

% The accuracy of a test is measured by the F1 score. Additionally, 
% True Negatives (TN) and False Negatives (FN) are crucial for our results, so we use the F1 score.
f1_Scores = 2*(Precision.*Recall)./(Precision+Recall);
