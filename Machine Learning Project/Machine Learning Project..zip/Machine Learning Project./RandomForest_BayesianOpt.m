tic
clear;
clc;


% importing the data
data = readtable('Breastcancer.csv');


% An analysis of the data indicates that three columns 
% (area_mean, area_se, and area_worst) contain substantial outliers.
summary(data);

% Independent and dependent variables separated
% The diagnosis feature will be my dependent variable (Y) because it is reliant on the other features. 
% As a result, the rest are independent features (X) because they are not dependent on anything.

indepen_X = table2array(data ...
    (:,3:32));
depen_y = table2array(data ...
    (:,2));

% Variables are saved
depen_var = data.Properties.VariableNames;
indepen_var = data(:,3:end);


% defining the classes

% The number of 'M'alignant tumors is 212 (1) and the number of 'B'enign tumors is 357 (0)
M_B_count = tabulate(depen_y); 

% use C_V partitioning to separate testing and traing data

C_V = cvpartition(depen_y, ...
    'holdout',0.3);
trainX = indepen_X(training ...
    (C_V,1),:);
trainy = depen_y(training ...
    (C_V,1));
testX = indepen_X(test ...
    (C_V,1),:);
testy = depen_y(test ...
    (C_V,1),:);


% In response to 3 significant outliers from the summary, 
% I normalized the data with mu=0 and standard deviation = 1.
[trainX, mu, stddev] = normalize(trainX);

for i=1:size(testX, 2)
    testX(:,i) = (testX(:,i) ...
        -mu(1,i))/stddev(1,i);
end


% As a result of the highly correlated dataset, the tuning of hyperparameters was done by Bayesian optimisation. 
% We generate one figure using this method (because we optimize three variables): 
% Defining the classes shows how the objective function is estimated and observed
% We create three variables with specific names, types, and ranges. 
% VTS 'NumVariablesToSample'  lc 'learning cycle'

VTS_a = optimizableVariable('VTS_a',[1, 50], ...
    'Type','integer');
split_a = optimizableVariable('split_a',{'gdi', 'deviance'}, ...
    'Type','categorical');
num_lc_a = optimizableVariable('num_lc_a',[10, 400], ...
    'Type','integer');
n2 = size(trainX, 1);
rng(1);
cv2 = cvpartition(n2, ...
    'Kfold',10);

% The objective function is to return a measure of the tuning loss for hyperparameters.
fun = @(x)kfoldLoss(fitcensemble(trainX, trainy, 'CVPartition', cv2, 'Method', 'Bag'));

% When trying for 150 observations, set the objective evaluation limit higher than the acquisition function 
% and expected improvement
bayesopt_results2 = bayesopt(fun,[VTS_a, split_a, num_lc_a],'Verbose',1, 'MaxObjectiveEvaluations',150);

% I have saved the best combination that gives the minimum error
vts_b_bo = bayesopt_results2.XAtMinObjective.VTS_a;
split_b_bo = bayesopt_results2.XAtMinObjective.split_a;
numlc_b_bo = bayesopt_results2.XAtMinObjective.num_lc_a;


% Minimum error for the set of hyperparameters that are evaluated on the validation set.
min_error = bayesopt_results2.MinObjective;


% Creating an optimised tree and generating results, and refit the RF with this tree template as the base learner
t = templateTree('NumVariablesToSample', vts_b_bo, ...
    'SplitCriterion', char(split_b_bo));

% refit the RF with this tree template as the base learner
rng(1)
bayes_opt_mdl_l = fitcensemble(trainX, trainy, 'Method', 'Bag', 'NumLearningCycles',numlc_b_bo,'learners', t);
bayes_opt_mdl_l_loss = loss(bayes_opt_mdl_l,testX, testy); % Using model predictions to classify training data
bayes_opt_mdl_l_rloss = resubLoss(bayes_opt_mdl_l); % Predictions that have been misclassified above. 


% Creating a matrix for Bayesian optimisation results and test model
figure()
bayesopt_Predict = predict(bayes_opt_mdl_l, testX);
Confmat_bayesopt_rf = confusionmat(bayesopt_Predict, testy);
matrix = confusionchart(bayesopt_Predict, testy);

% Accuracy of Random Forest model with bayesopt tuning.
accuracyRF = 100*(Confmat_bayesopt_rf(1,1)+Confmat_bayesopt_rf(2,2))./(Confmat_bayesopt_rf(1,1)+ ...
    Confmat_bayesopt_rf(2,2)+Confmat_bayesopt_rf(1,2)+Confmat_bayesopt_rf(2,1));

% Model accuracy with Bayes optimization tuning
precisionRF = Confmat_bayesopt_rf(1,1)./(Confmat_bayesopt_rf(1,1)+Confmat_bayesopt_rf(1,2));

% As a result of recall, we can figure out how many samples have a real chance of being tumor positive.
recallRF = Confmat_bayesopt_rf(1,1)./(Confmat_bayesopt_rf(1,1)+Confmat_bayesopt_rf(2,1));

% The accuracy of a test is measured by the F1 score. Additionally, 
% True Negatives (TN) and False Negatives (FN) are crucial for our results, so we use the F1 score.
f1ScoresRF = 2*(precisionRF.*recallRF)./(precisionRF+recallRF);
